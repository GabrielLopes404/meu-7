import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { BeforeAfter } from "@shared/schema";

export function BeforeAfterSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);

  const { data: items = [], isLoading } = useQuery<BeforeAfter[]>({
    queryKey: ["/api/before-after"],
  });

  if (isLoading || items.length === 0) return null;

  const currentItem = items[currentIndex];

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(e.clientX - rect.left, rect.width));
    const percent = (x / rect.width) * 100;
    setSliderPosition(percent);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const touch = e.touches[0];
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(touch.clientX - rect.left, rect.width));
    const percent = (x / rect.width) * 100;
    setSliderPosition(percent);
  };

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % items.length);
    setSliderPosition(50);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + items.length) % items.length);
    setSliderPosition(50);
  };

  return (
    <section className="py-20 md:py-32 bg-background" data-testid="section-before-after">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 space-y-4">
          <h2 className="font-display font-bold text-4xl md:text-5xl lg:text-6xl uppercase tracking-tight" data-testid="text-beforeafter-title">
            Por isso sou um dos <span className="text-primary">melhores</span>
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Com anos de experiência e mais de 350 projetos entregues, tenho propriedade para afirmar: sou bom no que faço... e os resultados comprovam isso.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div
            className="relative aspect-video rounded-lg overflow-hidden select-none"
            onMouseMove={handleMouseMove}
            onMouseDown={() => setIsDragging(true)}
            onMouseUp={() => setIsDragging(false)}
            onMouseLeave={() => setIsDragging(false)}
            onTouchMove={handleTouchMove}
            onTouchStart={() => setIsDragging(true)}
            onTouchEnd={() => setIsDragging(false)}
            data-testid="beforeafter-slider"
          >
            <div className="absolute inset-0">
              <img
                src={currentItem.afterImageUrl}
                alt="Depois"
                className="w-full h-full object-cover"
              />
            </div>

            <div
              className="absolute inset-0 overflow-hidden"
              style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
            >
              <img
                src={currentItem.beforeImageUrl}
                alt="Antes"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="absolute top-4 left-4 bg-background/80 backdrop-blur-sm px-4 py-2 rounded-full">
              <span className="text-sm font-bold uppercase tracking-wider" data-testid="label-before">Antes</span>
            </div>

            <div className="absolute top-4 right-4 bg-primary/80 backdrop-blur-sm px-4 py-2 rounded-full">
              <span className="text-sm font-bold uppercase tracking-wider text-primary-foreground" data-testid="label-after">Depois</span>
            </div>

            <div
              className="absolute top-0 bottom-0 w-1 bg-primary cursor-ew-resize"
              style={{ left: `${sliderPosition}%` }}
            >
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 bg-primary rounded-full flex items-center justify-center shadow-lg">
                <div className="flex gap-1">
                  <ChevronLeft className="w-4 h-4 text-primary-foreground" />
                  <ChevronRight className="w-4 h-4 text-primary-foreground" />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center space-y-4">
            <h3 className="font-display font-bold text-2xl" data-testid={`text-beforeafter-client-${currentIndex}`}>
              {currentItem.client}
            </h3>
            <p className="text-muted-foreground" data-testid={`text-beforeafter-title-${currentIndex}`}>{currentItem.title}</p>

            <div className="flex items-center justify-center gap-4 pt-4">
              <Button
                variant="outline"
                size="icon"
                onClick={prevSlide}
                disabled={items.length <= 1}
                data-testid="button-prev-beforeafter"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>

              <div className="flex gap-2">
                {items.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setCurrentIndex(index);
                      setSliderPosition(50);
                    }}
                    className={`w-2 h-2 rounded-full transition-all ${
                      index === currentIndex ? "bg-primary w-8" : "bg-muted"
                    }`}
                    data-testid={`dot-beforeafter-${index}`}
                  />
                ))}
              </div>

              <Button
                variant="outline"
                size="icon"
                onClick={nextSlide}
                disabled={items.length <= 1}
                data-testid="button-next-beforeafter"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
