import { Button } from "@/components/ui/button";
import { ArrowDown, Sparkles, Code2, Palette } from "lucide-react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useEffect, useState } from "react";

export function Hero() {
  const [isClient, setIsClient] = useState(false);
  const { scrollY } = useScroll();
  
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);
  const scale = useTransform(scrollY, [0, 300], [1, 0.95]);
  const y = useTransform(scrollY, [0, 300], [0, 50]);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const scrollToPortfolio = () => {
    const element = document.getElementById("portfolio");
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  const titleVariants = {
    hidden: { scale: 0.8, opacity: 0 },
    visible: {
      scale: 1,
      opacity: 1,
      transition: {
        duration: 1,
        ease: [0.22, 1, 0.36, 1],
      },
    },
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#050505]" data-testid="section-hero">
      {/* Animated Grid Background */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1.5 }}
        className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:4rem_4rem] md:bg-[size:6rem_6rem]"
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent" />
      
      {/* Floating Orbs - Responsive sizes */}
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{
          opacity: [0.3, 0.5, 0.3],
          scale: [1, 1.1, 1],
          x: [0, 20, 0],
          y: [0, -20, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="absolute top-1/4 left-[5%] md:left-[10%] w-48 h-48 md:w-96 md:h-96 bg-primary/30 rounded-full blur-[80px] md:blur-[140px]"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{
          opacity: [0.2, 0.4, 0.2],
          scale: [1, 1.2, 1],
          x: [0, -30, 0],
          y: [0, 20, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
          delay: 1,
        }}
        className="absolute bottom-1/4 right-[5%] md:right-[10%] w-64 h-64 md:w-[500px] md:h-[500px] bg-primary/20 rounded-full blur-[100px] md:blur-[160px]"
      />
      
      {/* Central Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full max-w-4xl opacity-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,#ff00c8_0%,transparent_70%)]"></div>
      </div>

      <motion.div
        style={isClient ? { opacity, scale, y } : {}}
        className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-24 sm:pt-28 md:pt-32 pb-16 sm:pb-20 text-center"
      >
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-6 sm:space-y-8 md:space-y-10"
        >
          {/* Badge */}
          <motion.div variants={itemVariants} className="flex justify-center">
            <motion.div 
              className="relative inline-flex items-center gap-2 sm:gap-3 px-4 sm:px-6 py-2.5 sm:py-3 rounded-full overflow-hidden group cursor-default"
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 400 }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-primary/30 via-pink-500/30 to-primary/30 rounded-full blur-xl group-hover:blur-2xl transition-all duration-500"></div>
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-pink-500/20 rounded-full border-2 border-primary/50 backdrop-blur-sm"></div>
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/20 to-white/0"
                animate={{ x: ["-200%", "200%"] }}
                transition={{ duration: 3, repeat: Infinity, ease: "linear", repeatDelay: 2 }}
              />
              
              <div className="relative flex items-center gap-1.5 sm:gap-2 z-10">
                <motion.div
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                >
                  <Palette className="w-4 h-4 sm:w-5 sm:h-5 text-primary drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]" />
                </motion.div>
                <span className="text-white font-bold text-xs sm:text-sm uppercase tracking-wider drop-shadow-lg">Design Gráfico</span>
              </div>
              <div className="relative w-px h-4 sm:h-5 bg-gradient-to-b from-transparent via-primary to-transparent"></div>
              <div className="relative flex items-center gap-1.5 sm:gap-2 z-10">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                >
                  <Code2 className="w-4 h-4 sm:w-5 sm:h-5 text-primary drop-shadow-[0_0_8px_rgba(236,72,153,0.8)]" />
                </motion.div>
                <span className="text-white font-bold text-xs sm:text-sm uppercase tracking-wider drop-shadow-lg">Desenvolvimento Web</span>
              </div>
            </motion.div>
          </motion.div>

          {/* Main Title with Split Animation */}
          <motion.div variants={titleVariants} className="space-y-2 sm:space-y-4 md:space-y-6 relative">
            <h1 className="font-display font-black text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-[10rem] tracking-tight leading-none relative" data-testid="text-hero-title">
              <motion.span
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.3, ease: [0.22, 1, 0.36, 1] }}
                className="block text-white uppercase relative"
                style={{ 
                  letterSpacing: "-0.03em",
                  textShadow: "0 0 40px rgba(255,255,255,0.1), 0 0 80px rgba(255,255,255,0.05)"
                }}
              >
                LOPES
              </motion.span>
              <motion.span
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="block uppercase relative group"
                style={{ letterSpacing: "-0.03em" }}
              >
                <span className="relative inline-block">
                  <span className="absolute inset-0 bg-gradient-to-r from-primary via-pink-400 to-primary bg-clip-text text-transparent blur-2xl opacity-70"></span>
                  <span className="relative bg-gradient-to-r from-primary via-pink-400 to-primary bg-clip-text text-transparent">
                    DESIGNER
                  </span>
                </span>
                <motion.div
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ duration: 1, delay: 1, ease: [0.22, 1, 0.36, 1] }}
                  className="absolute -bottom-2 sm:-bottom-4 md:-bottom-6 left-1/2 -translate-x-1/2 w-32 sm:w-48 md:w-64 h-1 sm:h-1.5 md:h-2"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary to-transparent blur-sm"></div>
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary to-transparent"></div>
                </motion.div>
              </motion.span>
            </h1>
          </motion.div>

          {/* Subtitle */}
          <motion.div
            variants={itemVariants}
            className="max-w-xs sm:max-w-2xl md:max-w-4xl mx-auto px-4 sm:px-0 space-y-4 sm:space-y-6"
          >
            <p
              className="text-base sm:text-xl md:text-2xl lg:text-3xl text-white/90 font-medium leading-relaxed"
              data-testid="text-hero-subtitle"
            >
              Transformo marcas com{" "}
              <span className="relative inline-block group cursor-default">
                <span className="absolute inset-0 bg-gradient-to-r from-primary to-pink-500 blur-lg opacity-50 group-hover:opacity-70 transition-opacity"></span>
                <span className="relative text-transparent bg-clip-text bg-gradient-to-r from-primary to-pink-500 font-bold">
                  design estratégico
                </span>
              </span>{" "}
              e{" "}
              <span className="relative inline-block group cursor-default">
                <span className="absolute inset-0 bg-gradient-to-r from-pink-500 to-primary blur-lg opacity-50 group-hover:opacity-70 transition-opacity"></span>
                <span className="relative text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-primary font-bold">
                  sites profissionais
                </span>
              </span>{" "}
              que atraem, encantam e convertem.
            </p>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.8 }}
              className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-gradient-to-r from-primary/10 to-pink-500/10 border border-primary/30 backdrop-blur-sm"
            >
              <div className="flex items-center gap-2">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-2 h-2 rounded-full bg-primary shadow-[0_0_10px_rgba(236,72,153,0.8)]"
                ></motion.div>
                <span className="text-white/70 text-sm sm:text-base">
                  Mais de{" "}
                  <span className="text-primary font-black text-lg sm:text-xl drop-shadow-[0_0_10px_rgba(236,72,153,0.6)]">
                    350 projetos
                  </span>{" "}
                  entregues com excelência
                </span>
              </div>
            </motion.div>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            variants={itemVariants}
            className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-5 pt-4 sm:pt-8 px-4 sm:px-0"
          >
            <motion.a
              href="https://www.instagram.com/lopesdesigner_ofc/"
              target="_blank"
              rel="noopener noreferrer"
              data-testid="button-cta-hero"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                size="lg"
                className="w-full sm:w-auto text-sm sm:text-base px-6 sm:px-12 py-5 sm:py-8 bg-gradient-to-r from-primary via-pink-500 to-pink-600 hover:from-pink-600 hover:via-primary hover:to-primary relative overflow-hidden group shadow-[0_0_40px_rgba(236,72,153,0.6)] hover:shadow-[0_0_80px_rgba(236,72,153,1)] transition-all duration-500 border-0 rounded-xl"
              >
                <span className="relative z-10 flex items-center gap-2 sm:gap-3 font-black uppercase tracking-wider drop-shadow-lg">
                  <motion.div
                    animate={{ rotate: [0, 15, -15, 0] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  >
                    <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" />
                  </motion.div>
                  <span className="text-xs sm:text-base">SOLICITAR MEU PROJETO</span>
                </span>
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/30 to-white/0"
                  animate={{
                    x: ["-100%", "100%"]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "linear",
                    repeatDelay: 1
                  }}
                />
              </Button>
            </motion.a>
            <motion.button
              onClick={scrollToPortfolio}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
              className="group w-full sm:w-auto px-6 sm:px-10 py-5 sm:py-8 text-sm sm:text-base font-bold text-white border-2 border-white/30 hover:border-primary rounded-xl transition-all duration-300 hover:bg-primary/10 backdrop-blur-sm uppercase tracking-wider relative overflow-hidden"
            >
              <span className="relative z-10">VER PORTFOLIO</span>
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-primary/0 via-primary/20 to-primary/0"
                initial={{ x: "-100%" }}
                whileHover={{ x: "100%" }}
                transition={{ duration: 0.6 }}
              />
            </motion.button>
          </motion.div>

          {/* Scroll Indicator */}
          <motion.div
            variants={itemVariants}
            className="pt-8 sm:pt-16"
          >
            <motion.button
              onClick={scrollToPortfolio}
              className="inline-flex flex-col items-center gap-2 text-white/50 hover:text-primary transition-colors group"
              data-testid="button-scroll-down"
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              <span className="text-xs uppercase tracking-widest font-semibold">Descubra meu trabalho</span>
              <ArrowDown className="w-5 h-5 sm:w-6 sm:h-6 group-hover:text-primary" />
            </motion.button>
          </motion.div>
        </motion.div>
      </motion.div>

      {/* Bottom Gradient */}
      <div className="absolute bottom-0 left-0 right-0 h-24 sm:h-32 bg-gradient-to-t from-[#050505] to-transparent pointer-events-none"></div>
    </section>
  );
}
